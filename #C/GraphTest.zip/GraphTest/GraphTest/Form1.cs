using System.Diagnostics.Metrics;
using System.Text;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Linq;
using System.Reflection.Emit;
using Label = System.Windows.Forms.Label;

namespace GraphTest
{
    public partial class Form1 : Form
    {
        public double[] values = new double[101];   //values to be analyse
        public int valueSize = 0;                   //number of values, written in file
        public Label[] labels = new Label[9];       //array for labels, showing the partial grid 
        public int indexTemp = -1;                  //index number of mouse clicked value 
        double Max, Min, multiplier;
       

        public Form1()
        {
            InitializeComponent();

            labels[0] = l1;
            labels[1] = l2;
            labels[2] = l3;
            labels[3] = l4;
            labels[4] = l5;
            labels[5] = l6;
            labels[6] = l7;
            labels[7] = l8;
            labels[8] = l9;
        }

        private void OpenFile_btn_Click(object sender, EventArgs e)
        {        
            var fileContent = string.Empty;
            var filePath = string.Empty;
            status_txt.Text = "";
            Values_lb.Items.Clear();

            int counter = 0;

            //OpenFile.InitialDirectory = "c:\\";
            OpenFile.Filter = "txt files (*.txt)|*.txt";
            //OpenFile.FilterIndex = 2;
            OpenFile.RestoreDirectory = true;

            if (OpenFile.ShowDialog() == DialogResult.OK)
            {
                filePath = OpenFile.FileName;
                var fileStream = OpenFile.OpenFile();

                OpenFile_txt.Text = filePath;

                using (StreamReader reader = new StreamReader(fileStream))
                {
                    fileContent = reader.ReadToEnd();
                    string[] lines = fileContent.Split('\n');

                    foreach (string line in lines) {
                        try
                        {
                            if(line != "")
                            {
                                values[counter] = Convert.ToDouble(line);
                                counter++;
                                Values_lb.Items.Add(String.Format("{0:D2}:  {1}", counter, line));
                            }
                        }
                       
                        catch (Exception)
                        {
                            status_txt.Text = "Incorrect Value convertion from file!";
                        }
                    }
                    valueSize = counter;                                  
                }

                Max = values.Select(x => x)
                      .Where(x => x > 0)
                      .Max();

                Min = values.Select(x => x)
                                      .Where(x => x > 0)
                                      .Min();

                multiplier = (panel1.Height - 20) / (Max - Min); //calculate scale according to Max and Min values

                if (counter > 0)
                {
                    Draw(-1); //draw values as graphic
                }
                else
                {                  
                    ClearLabels();
                    panel1.Controls.Clear(); //clear graphic panel
                    this.Refresh();
                }
            }
        }

        void ClearLabels()
        {
            Max_lbl.Text = "";
            Min_lbl.Text = "";
            for (int i = 1; i < 10; i++)
            {
                labels[i - 1].Text = "";
            }
        }

        void Draw(int index)       
        {
            int ellipseSize = 2;

            Graphics g = panel1.CreateGraphics();
            Pen pMax = new Pen(Color.Red);
            Pen pMin = new Pen(Color.Blue);
            Pen pMid = new Pen(Color.LightGray);
            SolidBrush sBlack = new SolidBrush(Color.Black);
            SolidBrush sPink = new SolidBrush(Color.Pink);

            if (index == -1) //draw graphic from values, get from file
            {
                panel1.Controls.Clear();
                panel1.Refresh();

                Max_lbl.Text = string.Format("{0:F3}", Max);
                Min_lbl.Text = string.Format("{0:F3}", Min);

                g.DrawLine(pMax, 0, panel1.Height - 10 - Convert.ToInt16((Max - Min)  * multiplier) , 599, panel1.Height - 10 - Convert.ToInt16((Max - Min)* multiplier));
                g.DrawLine(pMin, 0, panel1.Height - 10 , 599, panel1.Height - 10);
                for (int i = 1; i < 10; i++)
                {
                    g.DrawLine(pMid, 0, panel1.Height - 10 - Convert.ToInt16(i * ((Max - Min) * multiplier)/10) , 599, panel1.Height - 10 - Convert.ToInt16(i * ((Max - Min) * multiplier) / 10));
                    labels[i - 1].Text = string.Format("{0:F3}", Min + (Max - Min) * i / 10);
                }     
                
                for (int i = 0; i < valueSize; i++)
                {
                    g.FillEllipse(sBlack, 5 * i + 5, panel1.Height - 10 - ellipseSize - Convert.ToInt16(((values[i]) - Min) * multiplier), ellipseSize * 2, ellipseSize * 2);
                }
            }
            else
            {                 
                if (index >= 0)
                {   //status_txt.Text = string.Format("index={0}  indexTemp={1}", index, indexTemp);
                    if(indexTemp>=0)
                    {
                        g.FillEllipse(sBlack, 5 * indexTemp + 5, panel1.Height - 10 - ellipseSize - Convert.ToInt16(((values[indexTemp]) - Min) * multiplier), ellipseSize * 2, ellipseSize * 2);
                    } 
                    g.FillEllipse(sPink, 5 * index + 5, panel1.Height - 10 - ellipseSize - Convert.ToInt16(((values[index]) - Min) * multiplier), ellipseSize * 2, ellipseSize * 2);     
 
                    indexTemp = index;
                } 
            } 
        }

        private void CreateFile_btn_Click(object sender, EventArgs e)
        {
            Random RandomMeas = new Random(0);

            double LowLimit;
            double HighLimit;
            double valueLimit;
            Int16 Iteration;
            double num;
            string strValue;

            try
            {
                LowLimit = Convert.ToDouble(lowLimit_txt.Text);
                HighLimit = Convert.ToDouble(highLimit_txt.Text);
                Iteration = Convert.ToInt16(maxIteration_txt.Text);
            }
            catch (Exception)
            {
                status_txt.Text = "Incorrect format for LoLimits, HighLimits or Iteration!";
                ClearLabels();
                return;
            }

            if (Iteration > 100)
            {
                status_txt.Text = "Iteration must be between 0 and 100!";
                ClearLabels();
                return;
            }

            if (HighLimit < LowLimit)
            {
                status_txt.Text = "HighLimit must be greater then LowLilit!";
                ClearLabels();
                return;
            }
    
            SaveFileDialog SaveFile = new SaveFileDialog();
            SaveFile.Filter = "txt files (*.txt)|*.txt";
            SaveFile.Title = "Save an Image File";
            SaveFile.DefaultExt = "txt";

            if (SaveFile.ShowDialog() == DialogResult.OK)
            {
                CreateFile_txt.Text = SaveFile.FileName;
   
                using (StreamWriter sw = File.CreateText(SaveFile.FileName))
                {
                    for (int i = 0; i < Iteration; i++)
                    {
                        num = RandomMeas.NextDouble();
                        valueLimit = num * (HighLimit - LowLimit) + LowLimit;
                        strValue = String.Format("{0:F3}",valueLimit);
                        sw.WriteLine(strValue);
                    }
                }

                OpenFile_txt.Text = "";
            }
        }

        private void Values_lb_MouseClick(object sender, MouseEventArgs e)
        {
            int index = Values_lb.IndexFromPoint(e.Location);
            Draw(index);
        }
    }
}