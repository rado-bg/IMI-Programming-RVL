﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestLinq
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter radius: ");
            double radius = double.Parse(Console.ReadLine());
            double P = 2 * Math.PI * radius;
            double S = Math.PI * Math.Pow(radius, 2);
            Console.WriteLine($"S = {S:F2}, P = {P:F2}");
        }
    }
}
