﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FilesIO
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*
            using (StreamReader reader = new StreamReader("d1.txt"))
            {
                int sum = 0;
                string line;
                while((line =reader.ReadLine()) != null)
                {
                    sum += int.Parse(line);
                   
                }
                Console.WriteLine($"Sum1 = {sum}");
            }

            using (StreamReader reader1 = new StreamReader("d2.txt"))
            {
                int sum = 0;
                string line;
                while ((line = reader1.ReadLine()) != null)
                {
                    sum += line.Split(' ').Select(x => int.Parse(x)).Select(x => 2*x).Sum();

                }
                Console.WriteLine($"Sum2 = {sum}");
            }

            using (StreamWriter writer = new StreamWriter ("output.txt", true)) //true - append
            {
                writer.WriteLine("Hello");
                writer.WriteLine("IMI");
                int a = 20;
                writer.WriteLine($"a = {a}");
            }
            */

           
            using (StreamReader reader1 = new StreamReader(@"C:\Users\Radomir\Desktop\myFiles\numbers.txt"))
            {
                using (StreamWriter writer = new StreamWriter(@"C:\Users\Radomir\Desktop\myFiles\outputs.txt")) 
                {
                    string line1;
                    string info;
                    int a = 0;

                    while ((line1 = reader1.ReadLine()) != null)
                    {
                        a = int.Parse(line1);
                        if (a % 2 == 0)
                        {
                            writer.WriteLine($"{line1} even");
                        } else
                        {
                            writer.WriteLine($"{line1} odd");
                        }                       
                    }
                }
            }

        }
    }


}
