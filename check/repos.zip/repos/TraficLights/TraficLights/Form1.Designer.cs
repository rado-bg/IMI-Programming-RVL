﻿namespace TraficLights
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.red_btn = new System.Windows.Forms.Button();
            this.yellow_btn = new System.Windows.Forms.Button();
            this.green_btn = new System.Windows.Forms.Button();
            this.control_btn = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.myTimer = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // red_btn
            // 
            this.red_btn.BackColor = System.Drawing.Color.White;
            this.red_btn.Enabled = false;
            this.red_btn.Location = new System.Drawing.Point(15, 18);
            this.red_btn.Name = "red_btn";
            this.red_btn.Size = new System.Drawing.Size(143, 80);
            this.red_btn.TabIndex = 0;
            this.red_btn.UseVisualStyleBackColor = false;
            // 
            // yellow_btn
            // 
            this.yellow_btn.BackColor = System.Drawing.Color.White;
            this.yellow_btn.Enabled = false;
            this.yellow_btn.Location = new System.Drawing.Point(15, 122);
            this.yellow_btn.Name = "yellow_btn";
            this.yellow_btn.Size = new System.Drawing.Size(143, 80);
            this.yellow_btn.TabIndex = 1;
            this.yellow_btn.UseVisualStyleBackColor = false;
            // 
            // green_btn
            // 
            this.green_btn.BackColor = System.Drawing.Color.White;
            this.green_btn.Enabled = false;
            this.green_btn.Location = new System.Drawing.Point(15, 229);
            this.green_btn.Name = "green_btn";
            this.green_btn.Size = new System.Drawing.Size(143, 80);
            this.green_btn.TabIndex = 2;
            this.green_btn.UseVisualStyleBackColor = false;
            // 
            // control_btn
            // 
            this.control_btn.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.control_btn.Location = new System.Drawing.Point(71, 362);
            this.control_btn.Name = "control_btn";
            this.control_btn.Size = new System.Drawing.Size(172, 57);
            this.control_btn.TabIndex = 3;
            this.control_btn.Text = "Start";
            this.control_btn.UseVisualStyleBackColor = true;
            this.control_btn.Click += new System.EventHandler(this.ctrl_btn_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Controls.Add(this.green_btn);
            this.panel1.Controls.Add(this.red_btn);
            this.panel1.Controls.Add(this.yellow_btn);
            this.panel1.Location = new System.Drawing.Point(71, 21);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(172, 325);
            this.panel1.TabIndex = 4;
            // 
            // myTimer
            // 
            this.myTimer.Interval = 1000;
            this.myTimer.Tick += new System.EventHandler(this.myTimer_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightGray;
            this.ClientSize = new System.Drawing.Size(321, 450);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.control_btn);
            this.Name = "Form1";
            this.Text = "TraficLights";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Button red_btn;
        private Button yellow_btn;
        private Button green_btn;
        private Button control_btn;
        private Panel panel1;
        private System.Windows.Forms.Timer myTimer;
    }
}