namespace TraficLights
{
    public partial class Form1 : Form
    {
        int seconds;
        public Form1()
        {
            InitializeComponent();
        }

        private void myTimer_Tick(object sender, EventArgs e)
        {
            seconds++;
            if(seconds<5)
            {
                //red
                red_btn.BackColor = Color.Red;
                yellow_btn.BackColor= Color.White;
                green_btn.BackColor= Color.White; 
            } else if (seconds < 6) {
                //redyellow
                red_btn.BackColor = Color.Red;
                yellow_btn.BackColor = Color.Yellow;
                green_btn.BackColor = Color.White;
            }
            else if (seconds < 11)
            {
                //green
                red_btn.BackColor = Color.White;
                yellow_btn.BackColor = Color.White;
                green_btn.BackColor = Color.Green;
            } else if (seconds< 12) {
                //yellow
                red_btn.BackColor = Color.White;
                yellow_btn.BackColor = Color.Yellow;
                green_btn.BackColor = Color.White;
                seconds = 0;
            }

}

        private void ctrl_btn_Click(object sender, EventArgs e)
        {
            if (myTimer.Enabled)
            {
                myTimer.Stop();
                control_btn.Text = "Start";
            } else
            {
                control_btn.Text = "Stop";
                seconds = 0;
                myTimer.Start();
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            myTimer.Stop();
        }
    }
}