﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace coordinates
{
    internal class Program
    {
        static void Main(string[] args)
        {
/*
            int[] nums = (int[])Console.ReadLine()
                                       .Split(' ')
                                       .Select(n => int.Parse(n))
                                       //.Select(n => 10*n)
                                       .ToArray();
            Console.WriteLine(nums.Length);
            Console.WriteLine(nums.Sum());
            Console.WriteLine(nums.Max());
            Console.WriteLine(nums.Min());
            Console.WriteLine(nums.Average());

            nums = nums.Select(n => 2*n).ToArray();

            nums.ToList().ForEach(x => Console.WriteLine(x));
*/
            int[] nums = (int[])Console.ReadLine()
                           .Split('#')
                           .Select(n => int.Parse(n))
                           .Where(n => n >= 10 && n <= 100)
                           .Take(5) //get first 5 elements
                           .Skip(3)
                           //.Select(n => n % 2 == 0 ? 0 : 2 * n)
                           .ToArray();

            nums.ToList().ForEach(n => Console.Write($"{n}; "));


        }
    }
}
