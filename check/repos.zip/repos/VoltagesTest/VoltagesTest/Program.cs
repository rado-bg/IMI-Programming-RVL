﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VoltagesTest
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double[] voltages = Console.ReadLine().Split(' ')
                                                  .Select(x => double.Parse(x))
                                                  .ToArray();

            double avg1 = Console.ReadLine().Split(' ')
                                      .Select(x => double.Parse(x))
                                      .Where(x => x >= 9.0 && x <= 11.0)
                                      .Average();

            double sum = 0;
            int valid = 0;
            foreach (var item in voltages)
            {
                if (item >= 9.0 && item <= 11.0)
                {
                    sum += item;
                    valid++;
                }
            }
            double avg = sum / valid;
            Console.WriteLine($"U = {avg:F2}");
            Console.WriteLine($"U = {avg1:F2}");

        }
    }
}
