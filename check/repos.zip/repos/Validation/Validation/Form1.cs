using System.Text.RegularExpressions;

namespace Validation
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Validate_bt_Click(object sender, EventArgs e)
        {
            string regex = @"^#[A-Z]{3}(#[+-]?[0-9]{1,5}){2}#(0|\+?359)8[789][0-9]{7}#$";

            if (!Regex.IsMatch(Input_tb.Text, regex))
            {
                MessageBox.Show("Invalid input");
                Input_tb.Text = "";
                return;              
            }

            string[] data = Input_tb.Text.Split("#").ToArray();

            Trigram_tb.Text = data[1];
            GSM_tb.Text = data[4];
            double r = (double)int.Parse(data[2]) / int.Parse(data[3]);
            Res_tb.Text = ($"{r:F2}");
        }
    }
}