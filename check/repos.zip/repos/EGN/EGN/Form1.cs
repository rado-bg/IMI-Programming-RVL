namespace EGN
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        static bool CheckEGN(string EGN)
        {
            int[] weights = { 2, 4, 8, 5, 10, 9, 7, 3, 6 };
            if (EGN.Length != 10)
            {
                return false;
            }

            foreach (var symbol in EGN)
            {
                if (!char.IsDigit(symbol))
                {
                    return false;
                }
            }

            int sum = 0;

            for (int i = 0; i < 9; i++)
            {
                sum += (int)(EGN[i] - '0') * weights[i];
            }

            int checkDigit = sum % 11;

            if (checkDigit == 10)
            {
                checkDigit = 0;
            }
            if (checkDigit != (int)(EGN[9] - '0'))
            {
                return false;
            }

            return true;
        }

        static string checkPol(string EGN)
        {
            if (((int)(EGN[8] - '0') % 2) == 0)
            {
                return "���";
            }
            else
            {
                return "����";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (CheckEGN(EGN_tb.Text))
            {
                MessageBox.Show($"�������!\n���:{checkPol(EGN_tb.Text)}", "��� ����",MessageBoxButtons.OK,MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("���������!", "��� ����",MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            EGN_tb.Text = "";
        }
    }
}