﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Resistor
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter R1: ");
            double r1 = double.Parse(Console.ReadLine());
            Console.Write("Enter R2: ");
            double r2 = double.Parse(Console.ReadLine());
            double re = r1 * r2 / (r1 + r2);
            string value = $"RE = {re:F2} kOhm";
            Console.WriteLine(value);

        }
    }
}
