﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exceptions
{
    internal class Program
    {

        static void Expt()
        {
            double num;
            if(double.TryParse(Console.ReadLine(), out num))
            {
                Console.WriteLine(num);
            }
            else
            {
                Console.WriteLine("Invalid data!");
            }

            try
            {   
                int[] nums = Console.ReadLine().Split(' ').Select(n => int.Parse(n)).ToArray();
                int result = nums[0] / nums[1];
                Console.WriteLine(result);
                // int num = Console.ReadLine().Split(' ').Select(n => int.Parse(n)).ToArray()[2];
                //Console.WriteLine(num);
            }

            catch (IndexOutOfRangeException)
            {
                Console.WriteLine("You have to input min 2 digits!");
            }
            catch(FormatException)
            {
                Console.WriteLine("You have to input only numbers!");
            }
            catch(DivideByZeroException)
            {
                Console.WriteLine("The second digit must be not zero");
            }
            catch (Exception)
            {
                Console.WriteLine("You have any problem!");
            }
        }

        static void dateVal()
        {
            string inputDate = Console.ReadLine();

            DateTime date;


            if (DateTime.TryParse(inputDate, out date))
            {
                Console.WriteLine($"Date {inputDate} is valid");
            }
            else
            {
                Console.WriteLine($"Date {inputDate} is invalid");
            }

            DateTime d2 = date.AddDays(450);
            Console.WriteLine($"{d2.ToString()}");
        }

        static void Main(string[] args)
        {
            //Expt();

            dateVal();

        }
    }
}
