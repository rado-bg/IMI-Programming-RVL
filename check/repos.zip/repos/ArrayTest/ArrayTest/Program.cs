﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayTest
{
    internal class Program
    {
        static void Main(string[] args)
        {
/*
            int[] numbers = { 4, 51, 24, 4, 56, 0 };
            for (int i = 0; i < numbers.Length; i++)
            {
                Console.WriteLine(numbers[i]);
            }
            string text = "IMI 123";

            for (int i = 0; i < text.Length; i++)
            {
                Console.WriteLine(text[i]);
            }
            var myVar = 10;
            myVar++;
            Console.WriteLine(myVar);
            var name = "text";
            name += " 1";
            Console.WriteLine(name);

            foreach (var item in numbers)
            {
                Console.WriteLine(item);
            }

            foreach (var item in name)
            {
                Console.WriteLine(item);
            }
*/
        }
    }
}
