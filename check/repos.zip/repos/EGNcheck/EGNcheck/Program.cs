﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EGNcheck
{
    internal class Program
    {
        static bool CheckEGN(string EGN)
        {
            int[] weights = { 2, 4, 8, 5, 10, 9, 7, 3, 6};
            if (EGN.Length != 10)
            {
                return false;
            }

            foreach (var symbol in EGN)
            {
                if (!char.IsDigit(symbol))
                {                  
                    return false;
                }
            }

            int sum = 0;

            for (int i = 0; i < 9; i++)
            {
                sum += (int)(EGN[i] - '0') * weights[i];
            }

            int checkDigit = sum % 11;

            if (checkDigit == 10)
            {
                checkDigit = 0;
            }
            if (checkDigit != (int)(EGN[9] - '0')) {
                return false;
            }

            return true;
        }

        static string checkPol(string EGN)
        {
            if(((int)(EGN[8] - '0') % 2) == 0) {
                return "Мъж";
            } else
            {
                return "Жена";
            }
        }

        static void Main(string[] args)
        {
            string EGN = "6101057509";
            if (CheckEGN(EGN))
            {
                Console.WriteLine("Валидно!");
            }
            else
            {
                Console.WriteLine("Невалидно!");
            }

            Console.WriteLine(checkPol(EGN)); ;
        }
    }
}
