


namespace FormValues
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Calculate_Click(object sender, EventArgs e)
        {

            double low = double.Parse(Low.Text);
            double high = double.Parse(High.Text);

            if (Max.Checked)
            {
                double result = Values.Text.Split(' ')
                                           .Select(x => double.Parse(x))
                                           .Where(x => x >= low && x <= high)
                                           .Max();
                Result.Text = $"Result: {result:F2}";
            }
            else if (Min.Checked)
            {
                double result = Values.Text.Split(' ')
                                           .Select(x => double.Parse(x))
                                           .Where(x => x >= low && x <= high)
                                           .Min();
                Result.Text = $"Result: {result:F2}";
            }
            else if (Sum.Checked)
            {
                double result = Values.Text.Split(' ')
                                           .Select(x => double.Parse(x))
                                           .Where(x => x >= low && x <= high)
                                           .Sum();
                Result.Text = $"Result: {result:F2}";
            }
            else if (Average.Checked)
            {
                double result = Values.Text.Split(' ')
                                           .Select(x => double.Parse(x))
                                           .Where(x => x >= low && x <= high)
                                           .Average();
                Result.Text = $"Result: {result:F2}";
            }



        }
    }
}