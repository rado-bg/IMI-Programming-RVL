﻿namespace FormValues
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Values = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Average = new System.Windows.Forms.RadioButton();
            this.Sum = new System.Windows.Forms.RadioButton();
            this.Min = new System.Windows.Forms.RadioButton();
            this.Max = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.High = new System.Windows.Forms.TextBox();
            this.Low = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Calculate = new System.Windows.Forms.Button();
            this.Result = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // Values
            // 
            this.Values.Location = new System.Drawing.Point(108, 31);
            this.Values.Name = "Values";
            this.Values.Size = new System.Drawing.Size(318, 27);
            this.Values.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(48, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Values:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Average);
            this.groupBox1.Controls.Add(this.Sum);
            this.groupBox1.Controls.Add(this.Min);
            this.groupBox1.Controls.Add(this.Max);
            this.groupBox1.Location = new System.Drawing.Point(48, 97);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(135, 161);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Res";
            // 
            // Average
            // 
            this.Average.AutoSize = true;
            this.Average.Location = new System.Drawing.Point(18, 121);
            this.Average.Name = "Average";
            this.Average.Size = new System.Drawing.Size(85, 24);
            this.Average.TabIndex = 3;
            this.Average.TabStop = true;
            this.Average.Text = "Average";
            this.Average.UseVisualStyleBackColor = true;
            // 
            // Sum
            // 
            this.Sum.AutoSize = true;
            this.Sum.ForeColor = System.Drawing.Color.Green;
            this.Sum.Location = new System.Drawing.Point(18, 91);
            this.Sum.Name = "Sum";
            this.Sum.Size = new System.Drawing.Size(59, 24);
            this.Sum.TabIndex = 2;
            this.Sum.TabStop = true;
            this.Sum.Text = "Sum";
            this.Sum.UseVisualStyleBackColor = true;
            // 
            // Min
            // 
            this.Min.AutoSize = true;
            this.Min.ForeColor = System.Drawing.Color.Blue;
            this.Min.Location = new System.Drawing.Point(18, 61);
            this.Min.Name = "Min";
            this.Min.Size = new System.Drawing.Size(55, 24);
            this.Min.TabIndex = 1;
            this.Min.TabStop = true;
            this.Min.Text = "Min";
            this.Min.UseVisualStyleBackColor = true;
            // 
            // Max
            // 
            this.Max.AutoSize = true;
            this.Max.ForeColor = System.Drawing.Color.Red;
            this.Max.Location = new System.Drawing.Point(18, 31);
            this.Max.Name = "Max";
            this.Max.Size = new System.Drawing.Size(58, 24);
            this.Max.TabIndex = 0;
            this.Max.TabStop = true;
            this.Max.Text = "Max";
            this.Max.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.High);
            this.groupBox2.Controls.Add(this.Low);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Location = new System.Drawing.Point(225, 97);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(201, 161);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Rmax";
            // 
            // High
            // 
            this.High.Location = new System.Drawing.Point(91, 93);
            this.High.Name = "High";
            this.High.Size = new System.Drawing.Size(104, 27);
            this.High.TabIndex = 3;
            // 
            // Low
            // 
            this.Low.Location = new System.Drawing.Point(92, 46);
            this.Low.Name = "Low";
            this.Low.Size = new System.Drawing.Size(103, 27);
            this.Low.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(18, 91);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 20);
            this.label3.TabIndex = 1;
            this.label3.Text = "High:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 20);
            this.label2.TabIndex = 0;
            this.label2.Text = "Low:";
            // 
            // Calculate
            // 
            this.Calculate.Location = new System.Drawing.Point(158, 288);
            this.Calculate.Name = "Calculate";
            this.Calculate.Size = new System.Drawing.Size(158, 37);
            this.Calculate.TabIndex = 4;
            this.Calculate.Text = "Calculate";
            this.Calculate.UseVisualStyleBackColor = true;
            this.Calculate.Click += new System.EventHandler(this.Calculate_Click);
            // 
            // Result
            // 
            this.Result.AutoSize = true;
            this.Result.Location = new System.Drawing.Point(168, 355);
            this.Result.Name = "Result";
            this.Result.Size = new System.Drawing.Size(52, 20);
            this.Result.TabIndex = 5;
            this.Result.Text = "Result:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(472, 405);
            this.Controls.Add(this.Result);
            this.Controls.Add(this.Calculate);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Values);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox Values;
        private Label label1;
        private GroupBox groupBox1;
        private RadioButton Average;
        private RadioButton Sum;
        private RadioButton Min;
        private RadioButton Max;
        private GroupBox groupBox2;
        private TextBox High;
        private TextBox Low;
        private Label label3;
        private Label label2;
        private Button Calculate;
        private Label Result;
    }
}