﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace IMIThreads
{
    internal class Program
    {
        static void Print1()
        {
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("DUT#1 TESTING");
                Thread.Sleep(100);
            }           
        }

        static void Print2()
        {
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("DUT#2 TESTING");
                Thread.Sleep(200);
            }
        }

        static void Print3()
        {
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("DUT#3 TESTING");
                Thread.Sleep(150);
            }
        }

        static void Print4()
        {
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("DUT#4 TESTING");
                Thread.Sleep(250);
            }
        }

        static void Print5()
        {
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("DUT#5 TESTING");
                Thread.Sleep(500);
            }
        }

        static void Main(string[] args)
        {
            Thread th1 = new Thread(Print1);
            Thread th2 = new Thread(Print2);
            Thread th3 = new Thread(Print3);
            Thread th4 = new Thread(Print4);
            Thread th5 = new Thread(Print5);

            th1.Start();
            th2.Start();
            th5.Start();

            th1.Join(); //продължава когато нишката приключ
            th2.Join();

            th3.Start();
            th4.Start();

            th3.Join();
            th4.Join();
            th5.Join();  

            Console.WriteLine("End testing..");
        }
    }
}
