namespace Timer
{
    public partial class Form1 : Form
    {
        int seconds;
        public Form1()
        {
            InitializeComponent();
        }

        private void myTimer_Tick(object sender, EventArgs e)
        {
            if (seconds > 0)
            {
                 seconds--;
            }
         
            sec_lbl.Text = seconds.ToString();
            if(seconds==0)
            {
                myTimer.Stop();
                MessageBox.Show("Ready!");
            }
        }

        private void start_btn_Click(object sender, EventArgs e)
        {
            if(!int.TryParse(sec_tb.Text, out seconds))
            {
                MessageBox.Show("Invalid seconds format");
                sec_tb.Text = "";
                return;
               
            }
            sec_lbl.Text = seconds.ToString();
            myTimer.Start();
        }

        private void stop_btn_Click(object sender, EventArgs e)
        {
            if(myTimer.Enabled)
            {
                myTimer.Stop();
                stop_btn.Text = "Continue";
                stop_btn.BackColor = Color.Blue;
            } else
            {
                myTimer.Start();
                stop_btn.Text = "Stop";
                stop_btn.BackColor = Color.Red;
            }
            
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            myTimer.Stop();
        }

        private void reset_btn_Click(object sender, EventArgs e)
        {
            myTimer.Stop();
            seconds = 0;
            sec_lbl.Text = "0";
            sec_tb.Text = "0";
            stop_btn.Text = "Stop";
            stop_btn.BackColor = Color.Red;

        }
    }
}