﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Me.ForeColor = Color.Aqua

    End Sub
End Class
