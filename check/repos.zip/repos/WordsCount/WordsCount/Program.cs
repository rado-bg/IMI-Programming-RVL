﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WordsCount
{
    internal class Program
    {
        static void Main(string[] args)
        {
            char[] separators = { ' ', '.', '!', '?', ',', '\'' };
            Console.ReadLine().ToLower()
                              .Split(separators)
                              .Distinct()
                              .Where(WordsCount => WordsCount.Length >3)
                              .OrderBy(word => word)
                              .ToList()
                              .ForEach(word => Console.WriteLine(word));
                               
        }
    }
}
