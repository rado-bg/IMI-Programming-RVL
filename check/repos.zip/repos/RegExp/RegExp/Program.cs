﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Schema;
using System.Text.RegularExpressions;

namespace RegExp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string trigram = Console.ReadLine();
            string pattern1 = "^[A-Z][A-Z][A-Z]$"; //begin with ^  A-Z and end with A-Z $
            string pattern2 = "^IMI-[0-9][0-9]-[A-Z][A-Z][A-Z]$";
            string pattern3 = "^...$"; //три каквито и да е символа
            string pattern4 = "^a*b$"; //предходният символ може да се повтаря 0 или повече пъти b, ab, aab ...
            string pattern5 = "^IMI[0-9]*$"; //IMI032, IMI ...
            string pattern6 = "^a+b$"; // powtorenie ot 1 do mnogo ab, aab .... a+b <=> aa*b
            string pattern7 = "^a?b$";// b, ab, опционално, но не търпи повторения
            string pattern8 = "^[A-Z]{3}$"; // {n} повтаря n на брой пъти  / a{3,6} - от 3 до 6 / a{3,} - min 3 / a{,6} - max 6
            string pattern9 = @"^(0|\+?359)8[789][0-9]{7}$"; // za GSM
            string pattern10 = @"^#[A-Z]{3}(#[+-]?[0-9]{1,5}){2}#(0|\+?359)8[789][0-9]{7}#$";

            if (Regex.IsMatch(trigram, pattern10))
            {
                Console.WriteLine("Valid trgram");
            } else
            {
                Console.WriteLine("Invalid trigram");
            }
        }
    }
}
