﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Sync
{
    
    internal class Program
    {
        static Semaphore sem = new Semaphore(0, 1); 
        static void F1()
        {
            Random rand = new Random();
            Thread.Sleep(rand.Next(1000, 2000));
            Console.WriteLine("Light on!");
            sem.Release();
        }

        static void F2()
        {
            sem.WaitOne();
            Console.WriteLine("In room");
        }

        static void Main(string[] args)
        {
            Thread t1 = new Thread(F1);
            Thread t2 = new Thread(F2);

            t1.Start();
            t2.Start();
        }
    }
}
