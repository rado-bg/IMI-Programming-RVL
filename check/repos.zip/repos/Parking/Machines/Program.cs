﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Machines
{ 
    internal class Program
    {
        static Semaphore sem = new Semaphore(0, 1);
        static void F1()
        {
            Thread.Sleep(500);
            Console.WriteLine("Machine ON");
            sem.Release();
        }
        static void F2()
        {
            sem.WaitOne();
            Console.WriteLine("Working");
            Thread.Sleep(500);
            sem.Release();
        }

        static void F3()
        {
            sem.WaitOne();
            Console.WriteLine("Machine stop");
        }
        static void Main(string[] args)
        {
            Thread t1 = new Thread(F1);
            Thread t2 = new Thread(F2);
            Thread t3 = new Thread(F3);

            t1.Start();
            t2.Start();
            t3.Start();
        }
    }
}
