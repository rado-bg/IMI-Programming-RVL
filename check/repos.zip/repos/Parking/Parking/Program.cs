﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace Parking
{
    internal class Program
    {
        static Mutex m = new Mutex();
        static Semaphore parking = new Semaphore(4, 4);
        static void Park()
        {
            

               Console.WriteLine($"Cars {Thread.CurrentThread.ManagedThreadId} is waiting...");
                parking.WaitOne();
                Console.WriteLine($"Cars {Thread.CurrentThread.ManagedThreadId} is parking...");
                Thread.Sleep(100);
                Console.WriteLine($"Cars {Thread.CurrentThread.ManagedThreadId} exit parking...");
                parking.Release();
                Thread.Sleep(1000);

  
        }
        static void Main(string[] args)
        {
            Thread[] threads = new Thread[6];
            for (int i = 0; i < threads.Length; i++)
            {
                threads[i] = new Thread(Park);
                threads[i].Start();
            }

            for (int i = 0; i < threads.Length; i++)
            {
                threads[i].Join();
            }
            Console.WriteLine("END");
        }
    }
}
