﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace HelloWorld1
{
    internal class Program
    {

        static void Main(string[] args)
        {   /*
            double pi = 3.14;
            int a = 20;
            int b = 30;
            decimal money = 45.67M;

            Console.WriteLine($"PI = {pi}");
            Console.Write("Hello, world!\n");
            Console.WriteLine("IMI");
            Console.Write("a = ");
            Console.WriteLine(a);
            Console.Write("b = ");
            Console.WriteLine(b);
            Console.WriteLine($"a = {a}\nb = {b}");
            Console.WriteLine(money);
            string name = "Stamat";
            string str1 = "IMI";
            string str2 = "Bulgaria";
            string str3 = str1 + " " + str2;
            Console.WriteLine($"My name is {name}");
            Console.WriteLine(str3);

            for (int i = 0; i < 2; i += 2)
            {
                Console.WriteLine(i);
            }
            string input= Console.ReadLine();
            Console.WriteLine(input);
            int n = int.Parse(input);

            Console.WriteLine($"This is number n: {n}");
            */

            string R1 = Console.ReadLine();
        }
    }
}
