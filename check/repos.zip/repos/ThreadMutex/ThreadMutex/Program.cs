﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ThreadMutex
{
    internal class Program
    {
        static int num;
        static Mutex mux = new Mutex();
        
        static void Test()
        { 
            for (int i = 0; i < 10; i++)
            {
                mux.WaitOne();
                num++;
                mux.ReleaseMutex();

                Console.WriteLine($"Testing...{Thread.CurrentThread.ManagedThreadId}");
                Thread.Sleep(100);
            }
        }
        static void Main(string[] args)
        {
            Thread[] threads = new Thread[10];
            for (int i = 0; i < threads.Length; i++)
            {
                threads[i] = new Thread(Test);
                threads[i].Start(); 
            }

            for (int i = 0; i < threads.Length; i++)
            {
                threads[i].Join();
            }
            Console.WriteLine($"Num = {num}");
        }
    }
}
